package mk.sedc.finalproject.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class TShirtsPage {
    private WebDriver driver;
    private WebDriverWait wait;
    private Actions hover;
    private final By addToCartButton = By.className("btn-default");

    private final By categoryName = By.className("cat-name");

    public TShirtsPage(WebDriver driver, WebDriverWait wait, Actions hover) {
        this.driver = driver;
        this.wait = wait;
        this.hover = hover;
    }

    public String returnCategoryName() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(this.categoryName)).getText();
    }

    public void addItemToCartByIndex(String index) {
        hover.moveToElement(wait.until(ExpectedConditions.visibilityOfElementLocated(By
                .xpath("/html/body/div/div[2]/div/div[3]/div[2]/ul/li[" + index + "]")))).perform();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By
                .xpath("/html/body/div/div[2]/div/div[3]/div[2]/ul/li["+index+"]/div/div[2]/div[2]/a[1]"))).click();
        wait.withTimeout(Duration.ofSeconds(10));
    }
}
