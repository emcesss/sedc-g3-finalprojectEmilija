package mk.sedc.finalproject.data.enums;

public enum Gender {
    MALE, FEMALE
}
