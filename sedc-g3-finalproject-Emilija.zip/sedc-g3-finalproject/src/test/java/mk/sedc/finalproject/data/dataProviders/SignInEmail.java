package mk.sedc.finalproject.data.dataProviders;

import org.testng.annotations.DataProvider;

public class SignInEmail {

    @DataProvider(name = "signInEmailNegativeScenarios")
    public static Object[][] signInEmailNegativeScenarios() {
        return new Object[][]{
                {"test@mail.com", "admin", "There is 1 error\nAuthentication failed."},
                {"test@mail.com", "", "There is 1 error\nPassword is required."},
                {"", "", "There is 1 error\nAn email address required."},
                {"test", "test", "There is 1 error\nInvalid email address."},
                {"emilija@admin.com", "test", "There is 1 error\nInvalid password."}
        };
    }

}
