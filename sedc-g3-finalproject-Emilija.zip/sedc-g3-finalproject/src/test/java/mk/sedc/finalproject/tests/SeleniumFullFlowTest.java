package mk.sedc.finalproject.tests;

import org.testng.annotations.Test;

import static mk.sedc.finalproject.data.enums.DressCategory.SUMMER;
import static mk.sedc.finalproject.data.enums.PaymentMethod.BANK_WIRE;

public class SeleniumFullFlowTest extends BaseTest{

    @Test(description = "Verify full flow test: sign in, add items to cart, work with cart, assert price and proceed to checkout")
    public void fullFlowTestPositiveScenario() throws InterruptedException {
        homePage.navigateToSignIn();
        authenticationPage.insertEmailSignIn("emilija@admin.com");
        authenticationPage.insertPasswordSignIn("admin");
        authenticationPage.clickSignIn();
        softAssert.assertEquals(accountPage.returnPageHeader(), "MY ACCOUNT");
        homePage.hoverOverDressesNav();
        homePage.chooseDressCategory(SUMMER);
        softAssert.assertEquals(dressesPage.returnCategoryName(), "SUMMER DRESSES ");
        dressesPage.addItemToCartByIndex("2");
        homePage.clickContinueShopping();
        homePage.navigateToTShirts();
        softAssert.assertEquals(tShirtsPage.returnCategoryName(), "T-SHIRTS ");
        tShirtsPage.addItemToCartByIndex("1");
        homePage.clickContinueShopping();
        homePage.navigateToDresses();
        softAssert.assertEquals(dressesPage.returnCategoryName(), "DRESSES ");
        dressesPage.addItemToCartByIndex("5");
        homePage.clickContinueShopping();
        homePage.navigateToCart();
        softAssert.assertEquals(cartPage.returnCartQuantity(), "3 Products");
        cartPage.deleteCartItemByIndex(1);
        Thread.sleep(4000);
        softAssert.assertEquals(cartPage.returnCartQuantity(), "2 Products");
        cartPage.increaseItemQuantityByIndex(0);
        Thread.sleep(4000);
        softAssert.assertEquals(cartPage.returnCartQuantity(), "3 Products");
        softAssert.assertEquals( cartPage.returnTotalPrice(), cartPage.calculateTotalPrice());
        softAssert.assertEquals(cartPage.returnTotalPayment(), cartPage.calculateTotalPayment());
        cartPage.clickProceedToCheckoutFromCart();
        softAssert.assertEquals(cartPage.returnCategoryName(), "ADDRESSES");
        cartPage.clickProceedToCheckout();
        softAssert.assertEquals(cartPage.returnCategoryName(), "SHIPPING");
        cartPage.agreeWithTermsOfService();
        cartPage.clickProceedToCheckoutFromCart();
        softAssert.assertEquals(cartPage.returnCategoryName(), "PLEASE CHOOSE YOUR PAYMENT METHOD");
        cartPage.choosePaymentMethod(BANK_WIRE);
        softAssert.assertEquals(cartPage.returnCategoryName(), "ORDER SUMMARY");
        cartPage.clickConfirmOrder();
        softAssert.assertEquals(cartPage.returnCategoryName(), "ORDER CONFIRMATION");
        softAssert.assertEquals(cartPage.assertOrderComplete(), "Your order on My Store is complete.");
        softAssert.assertAll();
    }

}
