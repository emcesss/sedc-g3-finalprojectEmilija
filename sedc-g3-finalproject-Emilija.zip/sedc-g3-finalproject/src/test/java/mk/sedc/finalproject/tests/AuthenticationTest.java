package mk.sedc.finalproject.tests;

import mk.sedc.finalproject.data.dataProviders.SignInEmail;
import org.testng.Assert;
import org.testng.annotations.Test;

public class AuthenticationTest extends BaseTest {

    @Test(priority = 1, description = "Verify unsuccessful sign in with invalid data",
            dataProvider = "signInEmailNegativeScenarios", dataProviderClass = SignInEmail.class)
    public void signInNegativeScenarios(String email, String password, String warningMessage) {
        homePage.navigateToSignIn();
        authenticationPage.insertEmailSignIn(email);
        authenticationPage.insertPasswordSignIn(password);
        authenticationPage.clickSignIn();
        Assert.assertEquals(authenticationPage.assertAlertWarning(), warningMessage);
    }

    @Test(priority = 2, description = "Verify successful sign in with valid data")
    public void signInPositiveScenario() {
        homePage.navigateToSignIn();
        authenticationPage.insertEmailSignIn("emilija@admin.com");
        authenticationPage.insertPasswordSignIn("admin");
        authenticationPage.clickSignIn();
        Assert.assertEquals(accountPage.returnPageHeader(), "MY ACCOUNT");
    }

    @Test(priority = 3, description = "Verify successful reset of email flow")
    public void forgotPasswordScenario() {
        homePage.navigateToSignIn();
        authenticationPage.clickForgotPassword();
        forgotPasswordPage.insertEmail("emilija@admin.com");
        forgotPasswordPage.clickRetrievePassword();
        softAssert.assertEquals(forgotPasswordPage.assertAlertSuccess(), "A confirmation email has been sent to your address: emilija@admin.com");
        forgotPasswordPage.navigateToAuthenticationPage();
        softAssert.assertEquals(authenticationPage.returnPageHeader(), "AUTHENTICATION");
        softAssert.assertAll();
    }

}
