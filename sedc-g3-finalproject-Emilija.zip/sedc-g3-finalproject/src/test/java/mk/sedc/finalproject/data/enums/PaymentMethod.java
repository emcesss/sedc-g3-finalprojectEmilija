package mk.sedc.finalproject.data.enums;

public enum PaymentMethod {
    BANK_WIRE, CHECK
}
