package mk.sedc.finalproject.pages;

import mk.sedc.finalproject.data.enums.PaymentMethod;
import mk.sedc.finalproject.tests.BaseTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class CartPage extends BaseTest {
    private WebDriver driver;
    private WebDriverWait wait;
    private By cartQuantityText = By.id("summary_products_quantity");
    private By totalPrice = By.cssSelector("tbody > tr > td.cart_total > .price");
    private By totalProductsPrice = By.id("total_product");
    private By totalShippingPrice = By.id("total_shipping");
    private By totalTaxPrice = By.id("total_tax");
    private By totalPaymentPrice = By.id("total_price");
    private By deleteItemIcon = By.cssSelector("tbody > tr > td.cart_delete > div > a.cart_quantity_delete");
    private By increaseItemQuantity = By.cssSelector("tbody > tr > td.cart_quantity > div.cart_quantity_button > a.cart_quantity_up");
    private By proceedToCheckoutButton = By.className("standard-checkout");
    private By proceedToCheckoutButton2 = By.xpath("//*[@id=\"center_column\"]/form/p/button");
    private By categoryName = By.className("page-heading");
    private By checkboxTermsOfService = By.id("uniform-cgv");
    private By bankWirePayment = By.className("bankwire");
    private By checkPayment = By.className("cheque");
    private By confirmOrderButton = By.xpath("/html/body/div/div[2]/div/div[3]/div/form/p/button");
    private By assertOrderCompleteText = By.xpath("/html/body/div/div[2]/div/div[3]/div/div/p/strong");

    public CartPage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public String returnCartQuantity() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(this.cartQuantityText)).getText();
    }

    public double calculateTotalPrice() {
        double totalPrice = 0.00;
        List<WebElement> totalPriceElement = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(this.totalPrice));
        for (WebElement element : totalPriceElement) {
            totalPrice = totalPrice + Double.parseDouble(element.getText().substring(1));
        }
        return Math.round(totalPrice * 100.0) / 100.0;
    }

    public double returnTotalPrice() {
        return Double.parseDouble(wait.until(ExpectedConditions.visibilityOfElementLocated(this.totalProductsPrice)).getText().substring(1));
    }

    public double calculateTotalPayment() {
        return Math.round((Double.parseDouble(wait.until(ExpectedConditions.visibilityOfElementLocated(this.totalProductsPrice)).getText().substring(1))
                + Double.parseDouble(wait.until(ExpectedConditions.visibilityOfElementLocated(this.totalShippingPrice)).getText().substring(1))
                + Double.parseDouble(wait.until(ExpectedConditions.visibilityOfElementLocated(this.totalTaxPrice)).getText().substring(1))) * 100.0) / 100.0;
    }

    public double returnTotalPayment() {
        return Double.parseDouble(wait.until(ExpectedConditions.visibilityOfElementLocated(this.totalPaymentPrice)).getText().substring(1));
    }

    public void deleteCartItemByIndex(int index) {
        List<WebElement> totalPriceElement = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(this.deleteItemIcon));
        for (int i = 0; i < totalPriceElement.size(); i++) {
            if (index == i) {
                totalPriceElement.get(i).click();
                wait.withTimeout(Duration.ofSeconds(5));
            }
        }
    }

    public void increaseItemQuantityByIndex(int index) {
        List<WebElement> increaseQuantityElement = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(this.increaseItemQuantity));
        for (int i = 0; i < increaseQuantityElement.size(); i++) {
            if (index == i) {
                increaseQuantityElement.get(i).click();
                wait.withTimeout(Duration.ofSeconds(5));
            }
        }
    }

    public void clickProceedToCheckoutFromCart() {

        wait.until(ExpectedConditions.visibilityOfElementLocated(proceedToCheckoutButton)).click();
        wait.withTimeout(Duration.ofSeconds(5));
    }

    public void clickProceedToCheckout() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(proceedToCheckoutButton2)).click();
        wait.withTimeout(Duration.ofSeconds(5));
    }

    public String returnCategoryName() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(this.categoryName)).getText();
    }

    public void agreeWithTermsOfService() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(checkboxTermsOfService)).click();
        wait.withTimeout(Duration.ofSeconds(5));
    }

    public void choosePaymentMethod(PaymentMethod paymentMethod) {
        if (paymentMethod.equals(PaymentMethod.BANK_WIRE))
            wait.until(ExpectedConditions.visibilityOfElementLocated(this.bankWirePayment)).click();
        else
            wait.until(ExpectedConditions.visibilityOfElementLocated(this.checkPayment)).click();
        wait.withTimeout(Duration.ofSeconds(5));
    }

    public void clickConfirmOrder() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(confirmOrderButton)).click();
        wait.withTimeout(Duration.ofSeconds(5));
    }

    public String assertOrderComplete() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(this.assertOrderCompleteText)).getText();
    }
}