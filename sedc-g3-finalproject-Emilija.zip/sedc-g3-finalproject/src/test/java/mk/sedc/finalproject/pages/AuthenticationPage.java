package mk.sedc.finalproject.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class AuthenticationPage {

    private WebDriver driver;
    private WebDriverWait wait;
    private final By emailAddressSignIn = By.id("email");
    private final By passwordSignIn = By.id("passwd");
    private final By signInButton = By.id("SubmitLogin");
    private final By forgotPasswordLink = By.xpath("/html/body/div/div[2]/div/div[3]/div/div/div[2]/form/div/p[1]/a");
    private final By emailAddressCreate = By.id("email_create");
    private final By createButton = By.id("SubmitCreate");
    private final By pageHeader = By.className("page-heading");
    private final By alertDanger = By.className("alert-danger");

    public AuthenticationPage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public String returnPageHeader() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(this.pageHeader)).getText();
    }

    public void insertEmailSignIn(String userEmail) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(this.emailAddressSignIn)).sendKeys(userEmail);
    }

    public void insertPasswordSignIn(String userPassword) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(this.passwordSignIn)).sendKeys(userPassword);
    }

    public void clickSignIn() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(signInButton)).click();
        wait.withTimeout(Duration.ofSeconds(10));
    }

    public void clickForgotPassword() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(forgotPasswordLink)).click();
    }

    public void insertEmailCreateAccount(String userEmail) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(this.emailAddressCreate)).sendKeys(userEmail);
    }

    public void clickCreateAccount() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(createButton)).click();
        wait.withTimeout(Duration.ofSeconds(10));
    }

    public String assertAlertWarning() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(this.alertDanger)).getText();
    }

}
