package mk.sedc.finalproject.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class AccountPage {

    private WebDriver driver;
    private WebDriverWait wait;
    private final By pageHeader = By.className("page-heading");
    private final By signOutNavButton = By.className("btn btn-default button button-medium");

    public AccountPage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public String returnPageHeader() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(this.pageHeader)).getText();
    }

    public void clickSignOut() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(this.signOutNavButton)).click();
        wait.withTimeout(Duration.ofSeconds(7));
    }
}
