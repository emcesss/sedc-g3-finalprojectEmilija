package mk.sedc.finalproject.data.dataProviders;

import org.testng.annotations.DataProvider;

public class RegisterEmail {

    @DataProvider(name = "registerEmailNegativeScenarios")
    public static Object[][] registerEmailNegativeScenarios() {
        return new Object[][]{
                {"test@mail.com", "An account using this email address has already been registered. Please enter a valid password or request a new one."},
                {"", "Invalid email address."},
                {"test", "Invalid email address."}
        };
    }
}
