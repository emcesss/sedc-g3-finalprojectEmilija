package mk.sedc.finalproject.tests;

import io.github.bonigarcia.wdm.WebDriverManager;
import mk.sedc.finalproject.pages.*;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.asserts.SoftAssert;

import java.time.Duration;

public class BaseTest {

    public WebDriver driver;
    public WebDriverWait wait;
    public Actions hover;
    public String browser = "chrome";
    public static final int TIMEOUT = 20;
    public static final String URL = "http://automationpractice.com";
    public HomePage homePage;
    public CartPage cartPage;
    public AuthenticationPage authenticationPage;
    public RegistrationPage registrationPage;
    public ForgotPasswordPage forgotPasswordPage;
    public AccountPage accountPage;
    public SoftAssert softAssert;
    public DressesPage dressesPage;
    public TShirtsPage tShirtsPage;

    @BeforeMethod
    public void beforeMethod() {
        if (browser.equalsIgnoreCase("chrome")) {
            WebDriverManager.chromedriver().setup();
            driver = new ChromeDriver();
        } else if (browser.equalsIgnoreCase("firefox")) {
            WebDriverManager.firefoxdriver().setup();
            driver = new FirefoxDriver();
        } else if (browser.equalsIgnoreCase("edge")) {
            WebDriverManager.edgedriver().setup();
            driver = new EdgeDriver();
        } else if (browser.equalsIgnoreCase("ie")) {
            WebDriverManager.iedriver().setup();
            driver = new InternetExplorerDriver();
        } else {
            WebDriverManager.chromedriver().setup();
            driver = new ChromeDriver();
        }

        wait = new WebDriverWait(driver, Duration.ofSeconds(TIMEOUT));

        hover = new Actions(driver);
        homePage = new HomePage(driver, wait, hover);
        cartPage = new CartPage(driver, wait);
        authenticationPage = new AuthenticationPage(driver, wait);
        registrationPage = new RegistrationPage(driver, wait);
        forgotPasswordPage = new ForgotPasswordPage(driver, wait);
        accountPage = new AccountPage(driver, wait);
        dressesPage = new DressesPage(driver, wait, hover);
        tShirtsPage = new TShirtsPage(driver, wait, hover);
        softAssert = new SoftAssert();
        driver.manage().window().maximize();
        driver.navigate().to(URL);
    }

    @AfterMethod
    public void afterMethod() {
        driver.quit();
    }

    public void sleep(int timeout) {
        try {
            Thread.sleep(timeout);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void scroll(int h, int v) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(" + h + "," + v + ")");
    }
}

    /*public void scroll(int h, int v) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,1000)");
    }
}
*/
