package mk.sedc.finalproject.pages;

import mk.sedc.finalproject.data.enums.Gender;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class RegistrationPage {

    private WebDriver driver;
    private WebDriverWait wait;
    private final By maleGender = By.id("uniform-id_gender1");
    private final By femaleGender = By.id("uniform-id_gender2");
    private final By firstNameCustomerField = By.id("customer_firstname");
    private final By lastNameCustomerField = By.id("customer_lastname");
    private final By passwordField = By.id("passwd");
    private final By dateDay = By.id("uniform-days");
    private final By dateMonth = By.id("uniform-months");
    private final By dateYear = By.id("uniform-years");
    private final By companyField = By.id("company");
    private final By addressField = By.id("address1");
    private final By additionalAddressField = By.id("address2");
    private final By cityField = By.id("city");
    private final By stateField = By.id("uniform-id_state");
    private final By zipPostalCodeField = By.id("postcode");
    private final By countryField = By.id("uniform-id_country");
    private final By additionalInformationField = By.id("other");
    private final By homePhoneField = By.id("phone");
    private final By mobilePhoneField = By.id("phone_mobile");
    private final By aliasAddressField = By.id("alias");
    private final By registerButton = By.id("submitAccount");
    private final By pageHeader = By.className("page-heading");

    public RegistrationPage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public String returnPageHeader() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(this.pageHeader)).getText();
    }

    public void chooseGender(Gender gender) {
        if (gender.equals(Gender.MALE))
            wait.until(ExpectedConditions.visibilityOfElementLocated(this.maleGender)).click();
        else
            wait.until(ExpectedConditions.visibilityOfElementLocated(this.femaleGender)).click();
    }

    public void insertCustomerFirstName(String firstName) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(this.firstNameCustomerField)).sendKeys(firstName);
    }

    public void insertCustomerLastName(String lastName) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(this.lastNameCustomerField)).sendKeys(lastName);
    }

    public void insertCustomerPassword(String password){
        wait.until(ExpectedConditions.visibilityOfElementLocated(this.passwordField)).sendKeys(password);
    }

    public void chooseDayOfBirth(String day) {
        WebElement daysElement = wait.until(ExpectedConditions.visibilityOfElementLocated(this.dateDay));
        daysElement.click();
        chooseDropdownOptionFromWebElement(day, daysElement);
    }

    public void chooseMonthOfBirth(String month) {
        WebElement monthsElement = wait.until(ExpectedConditions.visibilityOfElementLocated(this.dateMonth));
        monthsElement.click();
        chooseDropdownOptionFromWebElement(month, monthsElement);
    }

    public void chooseYearOfBirth(String year) {
        WebElement yearsElement = wait.until(ExpectedConditions.visibilityOfElementLocated(this.dateYear));
        yearsElement.click();
        chooseDropdownOptionFromWebElement(year, yearsElement);
    }

    public void insertCompany(String company){
        wait.until(ExpectedConditions.visibilityOfElementLocated(this.companyField)).sendKeys(company);
    }

    public void insertAddress(String address) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(this.addressField)).sendKeys(address);
    }

    public void insertAdditionalAddress(String address) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(this.additionalAddressField)).sendKeys(address);
    }

    public void insertCity(String city){
        wait.until(ExpectedConditions.visibilityOfElementLocated(this.cityField)).sendKeys(city);
    }

    public void chooseState(String state) {
        WebElement stateElement = wait.until(ExpectedConditions.visibilityOfElementLocated(this.stateField));
        stateElement.click();
        chooseDropdownOptionFromWebElement(state, stateElement);
    }

    public void insertZipPostalCode(String zipPostalCode){
        wait.until(ExpectedConditions.visibilityOfElementLocated(this.zipPostalCodeField)).sendKeys(zipPostalCode);
    }

    public void chooseCountry(String country) {
        WebElement countryElement = wait.until(ExpectedConditions.visibilityOfElementLocated(this.countryField));
        countryElement.click();
        chooseDropdownOptionFromWebElement(country, countryElement);
    }

    public void insertAdditionalInformation(String additionalInformation){
        wait.until(ExpectedConditions.visibilityOfElementLocated(this.additionalInformationField)).sendKeys(additionalInformation);
    }

    public void insertHomePhone(String homePhone) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(this.homePhoneField)).sendKeys(homePhone);
    }

    public void insertMobilePhone(String mobilePhone) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(this.mobilePhoneField)).sendKeys(mobilePhone);
    }

    public void insertAliasAddress(String aliasAddress){
        wait.until(ExpectedConditions.visibilityOfElementLocated(this.aliasAddressField)).clear();
        wait.until(ExpectedConditions.visibilityOfElementLocated(this.aliasAddressField)).sendKeys(aliasAddress);
    }

    public void clickRegister() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(registerButton)).click();
        wait.withTimeout(Duration.ofSeconds(7));
    }

    private void chooseDropdownOptionFromWebElement(String dropdownOption, WebElement webElement) {
        List<WebElement> daysList = wait.until(ExpectedConditions.visibilityOfNestedElementsLocatedBy(webElement, By.tagName("option")));
        for (WebElement option : daysList) {
            String optionText = option.getText();
            if (optionText.contains(dropdownOption)) {
                option.click();
                break;
            }
        }
    }

}
