package mk.sedc.finalproject.pages;

import mk.sedc.finalproject.data.enums.DressCategory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

import static mk.sedc.finalproject.data.enums.DressCategory.*;

public class HomePage {

    private WebDriver driver;
    private WebDriverWait wait;
    private Actions hover;
    private By signIn = By.className("login");
    private By dressesNav = By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[6]/ul/li[2]/a");
    private By casualDressesNav = By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[6]/ul/li[2]/ul/li[1]/a");
    private By eveningDressesNav = By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[6]/ul/li[2]/ul/li[2]/a");
    private By summerDressesNav = By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[6]/ul/li[2]/ul/li[3]/a");
    private By tShirtsNav = By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[6]/ul/li[3]/a");
    private By cartButton = By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[3]/div/a");
    private By alertCart = By.className("alert-warning");
    private By continueShopping = By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[4]/div[1]/div[2]/div[4]/span");

    public HomePage(WebDriver driver, WebDriverWait wait, Actions hover) {
        this.driver = driver;
        this.wait = wait;
        this.hover = hover;
    }

    public void navigateToSignIn() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(signIn)).click();
        wait.withTimeout(Duration.ofSeconds(15));
    }

    public void hoverOverDressesNav() {
        hover.moveToElement(wait.until(ExpectedConditions.visibilityOfElementLocated(dressesNav))).perform();
        wait.withTimeout(Duration.ofSeconds(5));
    }

    public void chooseDressCategory(DressCategory category) {
        if (category.equals(CASUAL)) {
            wait.until(ExpectedConditions.visibilityOfElementLocated(casualDressesNav)).click();
        } else if (category.equals(EVENING)) {
            wait.until(ExpectedConditions.visibilityOfElementLocated(eveningDressesNav)).click();
        } else {
            wait.until(ExpectedConditions.visibilityOfElementLocated(summerDressesNav)).click();
        }
        wait.withTimeout(Duration.ofSeconds(4));
    }

    public void navigateToDresses() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(dressesNav)).click();
        wait.withTimeout(Duration.ofSeconds(4));
    }

    public void navigateToTShirts() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(tShirtsNav)).click();
        wait.withTimeout(Duration.ofSeconds(4));
    }

    public void navigateToCart() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(cartButton)).click();
        wait.withTimeout(Duration.ofSeconds(7));
    }

    public String assertAlertWarning() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(this.alertCart)).getText();
    }

    public void clickContinueShopping() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(continueShopping)).click();
        wait.withTimeout(Duration.ofSeconds(7));
    }

}