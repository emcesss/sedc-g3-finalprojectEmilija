package mk.sedc.finalproject.data.enums;

public enum DressCategory {
    CASUAL, EVENING, SUMMER
}
