package mk.sedc.finalproject.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import static mk.sedc.finalproject.data.enums.DressCategory.*;

public class ShoppingTest extends BaseTest{

    @Test(priority = 1, description = "Verify shopping flow")
    public void navigateThroughCategoriesAddItemsToCartWorkWithCartAndProceedToCheckout() throws InterruptedException {
        homePage.hoverOverDressesNav();
        homePage.chooseDressCategory(SUMMER);
        softAssert.assertEquals(dressesPage.returnCategoryName(), "SUMMER DRESSES ");
        dressesPage.addItemToCartByIndex("3");
        homePage.clickContinueShopping();
        homePage.navigateToTShirts();
        softAssert.assertEquals(tShirtsPage.returnCategoryName(), "T-SHIRTS ");
        tShirtsPage.addItemToCartByIndex("1");
        homePage.clickContinueShopping();
        homePage.navigateToDresses();
        softAssert.assertEquals(dressesPage.returnCategoryName(), "DRESSES ");
        dressesPage.addItemToCartByIndex("2");
        homePage.clickContinueShopping();
        homePage.navigateToCart();
        softAssert.assertEquals(cartPage.returnCartQuantity(), "3 Products");
        cartPage.deleteCartItemByIndex(1);
        Thread.sleep(4000);
        softAssert.assertEquals(cartPage.returnCartQuantity(), "2 Products");
        cartPage.increaseItemQuantityByIndex(0);
        Thread.sleep(4000);
        softAssert.assertEquals(cartPage.returnCartQuantity(), "3 Products");
        softAssert.assertEquals( cartPage.returnTotalPrice(), cartPage.calculateTotalPrice());
        softAssert.assertEquals(cartPage.returnTotalPayment(), cartPage.calculateTotalPayment());
        softAssert.assertAll();
    }

    @Test(priority = 2, description = "Verify empty shopping cart if nothing is added to cart")
    public void navigateToEmptyCart() {
        homePage.navigateToCart();
        Assert.assertEquals(homePage.assertAlertWarning(), "Your shopping cart is empty.");
    }
}
