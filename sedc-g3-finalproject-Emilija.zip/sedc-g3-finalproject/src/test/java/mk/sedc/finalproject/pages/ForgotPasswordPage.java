package mk.sedc.finalproject.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class ForgotPasswordPage {

    private WebDriver driver;
    private WebDriverWait wait;
    private final By emailAddress = By.id("email");
    private final By retrievePasswordButton = By.xpath("/html/body/div/div[2]/div/div[3]/div/div/form/fieldset/p/button");
    private final By alertSuccess = By.className("alert-success");
    private final By authenticationNavigation = By.xpath("/html/body/div/div[2]/div/div[1]/a[2]");

    public ForgotPasswordPage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public void insertEmail(String userEmail) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(this.emailAddress)).sendKeys(userEmail);
    }

    public void clickRetrievePassword() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(retrievePasswordButton)).click();
        wait.withTimeout(Duration.ofSeconds(7));
    }

    public String assertAlertSuccess() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(alertSuccess)).getText();
    }

    public void navigateToAuthenticationPage() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(authenticationNavigation)).click();
        wait.withTimeout(Duration.ofSeconds(7));
    }

}
