package mk.sedc.finalproject.tests;

import mk.sedc.finalproject.data.dataProviders.RegisterEmail;
import org.testng.Assert;
import org.testng.annotations.Test;

import static mk.sedc.finalproject.data.enums.Gender.FEMALE;

public class RegistrationTest extends BaseTest {

    @Test(priority = 1, description = "Positive scenario = Verify successful registration")
    public void RegisterWithRandomlyGeneratedEmail() {
        homePage.navigateToSignIn();
        softAssert.assertEquals(authenticationPage.returnPageHeader(), "AUTHENTICATION");
        authenticationPage.insertEmailCreateAccount("test" + System.currentTimeMillis() + "@mail.com");
        authenticationPage.clickCreateAccount();
        registrationPage.chooseGender(FEMALE);
        registrationPage.insertCustomerFirstName("Emilija");
        registrationPage.insertCustomerLastName("Tasevska");
        registrationPage.insertCustomerPassword("ema1234tas");
        registrationPage.chooseDayOfBirth("2");
        registrationPage.chooseMonthOfBirth("December");
        registrationPage.chooseYearOfBirth("1982");
        registrationPage.insertCompany("Seavus");
        registrationPage.insertAddress("Bul. V.S. Bato");
        registrationPage.insertAdditionalAddress("65-3/5");
        registrationPage.insertCity("Skopje");
        registrationPage.chooseState("California");
        registrationPage.insertZipPostalCode("35004");
        registrationPage.chooseCountry("United States");
        registrationPage.insertAdditionalInformation("This is a test");
        registrationPage.insertHomePhone("+38922654789");
        registrationPage.insertMobilePhone("+38975123456");
        registrationPage.insertAliasAddress("My Alias");
        softAssert.assertEquals(registrationPage.returnPageHeader(), "CREATE AN ACCOUNT");
        registrationPage.clickRegister();
        softAssert.assertEquals(accountPage.returnPageHeader(), "MY ACCOUNT");
        accountPage.clickSignOut();
        softAssert.assertEquals(authenticationPage.returnPageHeader(), "AUTHENTICATION");
        softAssert.assertAll();
    }

    @Test(priority = 2, description = "Negative scenario = Verify unsuccessful registration with: already used, invalid and empty email",
            dataProvider = "registerEmailNegativeScenarios", dataProviderClass = RegisterEmail.class)
    public void RegisterWithInvalidEmail(String email, String warningMessage) {
        homePage.navigateToSignIn();
        authenticationPage.insertEmailCreateAccount(email);
        authenticationPage.clickCreateAccount();
        Assert.assertEquals(authenticationPage.assertAlertWarning(), warningMessage);
    }

}
